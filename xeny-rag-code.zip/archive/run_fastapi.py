import uvicorn

if __name__ == "__main__":
    # ARCHIVED: Legacy runner for single-org app. Not used in multi-org system.
    # uvicorn.run(
    #     "main:app",
    #     host="0.0.0.0",
    #     port=8000,
    #     reload=True,
    #     log_level="info"
    # )
